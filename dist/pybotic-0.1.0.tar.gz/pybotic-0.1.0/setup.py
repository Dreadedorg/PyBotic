# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pybotic', 'pybotic.util']

package_data = \
{'': ['*']}

install_requires = \
['requests>=2.28.2,<3.0.0', 'websocket-client>=1.5.1,<2.0.0']

setup_kwargs = {
    'name': 'pybotic',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'BadPythonCoder',
    'author_email': 'xsare435@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
